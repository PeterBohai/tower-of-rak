
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.16.4'
version = '1.16.4'
full_version = '1.16.4'
git_revision = '7ebbc2ed3b4a388dd3942e1d8ef2de18074a09b3'
release = True

if not release:
    version = full_version
